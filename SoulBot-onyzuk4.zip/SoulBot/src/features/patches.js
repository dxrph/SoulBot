const { EmbedBuilder } = require('discord.js');
const { channelByKey } = require('../util');
const { toItalian } = require('../translate');

// Official Valve posts for Deadlock (app 1422450) from the public Steam news API
const APP_ID = 1422450;
const FEED = `https://api.steampowered.com/ISteamNews/GetNewsForApp/v2/?appid=${APP_ID}&count=15&maxlength=0`;
const INTERVAL_MS = 15 * 60_000;
const urlOf = (item) => `https://store.steampowered.com/news/app/${APP_ID}/view/${item.gid}`;

// Images in a post: [img]{STEAM_CLAN_LOC_IMAGE}/<clan>/<file>[/img] or [img]https://...[/img]
function imagesOf(text) {
  return [...text.matchAll(/\[img\]\s*(\S+?)\s*\[\/img\]/gi)]
    .map((m) => m[1].replace(/^\{STEAM_CLAN_(?:LOC_)?IMAGE\}/, 'https://clan.fastly.steamstatic.com/images'))
    .filter((u) => /^https?:\/\//.test(u));
}

// Steam BBCode -> plain Discord text
function clean(text) {
  return text
    .replace(/\{STEAM_CLAN_(LOC_)?IMAGE\}\S+/g, '')
    .replace(/\[\/?(h\d|b|i|u|list|olist|strike|p|quote|code|url|img|previewyoutube)[^\]]*\]/gi, '')
    .replace(/\[\*\]/g, '\n- ')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

// Each target is one channel: the English original, or the Italian translation
const TARGETS = [{ key: 'patches', italian: false }, { key: 'patches_it', italian: true }];

async function check(client) {
  const res = await fetch(FEED).catch(() => null);
  if (!res?.ok) return;
  const items = ((await res.json()).appnews?.newsitems ?? [])
    .filter((n) => n.feedname === 'steam_community_announcements')
    .sort((a, b) => a.date - b.date);
  if (!items.length) return;

  for (const guild of client.guilds.cache.values()) {
    for (const { key, italian } of TARGETS) {
      const ch = channelByKey(guild, key);
      if (!ch?.isTextBased()) { console.log(`patches: channel '${key}' not found in ${guild.name}`); continue; }

      const recent = await ch.messages.fetch({ limit: 50 }).catch(() => null);
      if (!recent) continue;
      // Dedup without a database, from what the bot already posted in this channel.
      // [...recent.values()]: a Collection's own flatMap/iteration does not give a plain list
      const mine = [...recent.values()].filter((m) => m.author.id === client.user.id).flatMap((m) => m.embeds).filter((e) => e.url);
      const posted = new Set(mine.map((e) => e.url));
      const lastPosted = Math.max(0, ...mine.map((e) => Date.parse(e.timestamp) || 0));

      // Only posts newer than the latest one already here: older ones must never reappear
      const fresh = posted.size
        ? (lastPosted ? items.filter((n) => !posted.has(urlOf(n)) && n.date * 1000 >= lastPosted) : [])
        : items.slice(-1); // first run: only the latest, don't flood the channel
      for (const n of fresh) {
        let title = n.title;
        let body = clean(n.contents);
        if (italian) {
          // On failure skip: the post stays "fresh" and is retried at the next check
          const [t, b] = [await toItalian(title), await toItalian(body)];
          if (t === null || b === null) { console.error('patches: translation failed, will retry at next check'); continue; }
          [title, body] = [t, b];
        }
        const images = imagesOf(n.contents).slice(0, 4);
        const main = new EmbedBuilder()
          .setColor(0xe67e22)
          .setTitle(title.slice(0, 256))
          .setURL(urlOf(n))
          .setDescription(body.length > 3800 ? `${body.slice(0, 3800)}…` : body || null)
          .setFooter({ text: italian ? 'Traduzione automatica · originale su Steam' : (n.author ? `by ${n.author}` : 'Deadlock') })
          .setTimestamp(n.date * 1000);
        if (images[0]) main.setImage(images[0]);
        // Embeds sharing the same url are shown by Discord as one image gallery
        const extra = images.slice(1).map((img) => new EmbedBuilder().setURL(urlOf(n)).setImage(img));
        await ch.send({ embeds: [main, ...extra] }).catch(console.error);
      }
    }
  }
}

function init(client) {
  client.once('clientReady', () => {
    let busy = false; // startup check and a manual trigger must not post the same patch twice
    const run = async () => {
      if (busy) return;
      busy = true;
      try { await check(client); } catch (e) { console.error(e); } finally { busy = false; }
    };
    setTimeout(run, 10_000);
    client.on('patchesCheck', run); // fired right after /add-tools or /sync-guides
    setInterval(run, INTERVAL_MS).unref();
  });
}

module.exports = { init };
